# Enhanced PowerShell script for installing Velociraptor MSI with dynamic file handling

# Function to log messages
function Log-Message {
    param (
        [string]$Message,
        [string]$Type = "INFO",
        [string]$LogPath
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "$timestamp [$Type] $Message"
    Add-Content -Path $LogPath -Value $logMessage
}

# Function to check DNS resolution and log result
function Check-DNS {
    param (
        [string]$Domain,
        [string]$LogPath
    )
    try {
        $dnsResult = Resolve-DnsName -Name $Domain -ErrorAction Stop
        Log-Message -Message "DNS resolution successful for $Domain. IP: $($dnsResult.IPAddress)" -LogPath $LogPath
        return $true
    } catch {
        $errorMessage = $_.Exception.Message
        Log-Message -Message ("DNS resolution failed for $Domain`:` " + $errorMessage) -Type "ERROR" -LogPath $LogPath
        return $false
    }
}

# Set log file path
$logPath = Join-Path -Path "C:\Windows\Temp" -ChildPath "velociraptor.install.log"

# Initial checks for Velociraptor configuration and installation status
$writebackFile = "C:\Program Files\Velociraptor\velociraptor.writeback.yaml"
if (Test-Path $writebackFile) {
    Log-Message -Message "Installation skipped: Configuration file already exists." -LogPath $logPath
    exit
}

# Configure package directory and dynamically find MSI
$PackageDir = if ($env:S1_PACKAGE_DIR_PATH) { $env:S1_PACKAGE_DIR_PATH } else { $PSScriptRoot }
$msiFile = Get-ChildItem -Path $PackageDir -Filter "velociraptor-*.msi" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $msiFile) {
    Log-Message -Message "No MSI file found matching 'velociraptor-*.msi' in the package directory." -Type "ERROR" -LogPath $logPath
    exit
}
$msiPath = $msiFile.FullName
Log-Message -Message "Starting installation from MSI: $msiPath" -LogPath $logPath

# Perform MSI installation with error handling
try {
    $process = Start-Process "msiexec.exe" -ArgumentList "/i", "`"$msiPath`"", "/qn", "/L*v", "`"$logPath`"" -Wait -NoNewWindow -PassThru
    if ($process.ExitCode -ne 0) {
        Log-Message -Message "MSI installation failed with exit code $($process.ExitCode)" -Type "ERROR" -LogPath $logPath
        exit
    } else {
        Log-Message -Message "MSI installation completed successfully." -LogPath $logPath
    }
} catch {
    Log-Message -Message "MSI installation encountered an error: $_" -Type "ERROR" -LogPath $logPath
    exit
}

# Verify and prepare Velociraptor directory
$velociraptorDir = "C:\Program Files\Velociraptor"
if (-not (Test-Path $velociraptorDir)) {
    try {
        New-Item -ItemType Directory -Path $velociraptorDir
        Log-Message -Message "Created directory: $velociraptorDir" -LogPath $logPath
    } catch {
        Log-Message -Message "Failed to create directory: $velociraptorDir - $_" -Type "ERROR" -LogPath $logPath
        exit
    }
} else {
    Log-Message -Message "Directory already exists: $velociraptorDir" -LogPath $logPath
}

# Dynamically find config file
$configFile = Get-ChildItem -Path $PackageDir -Filter "client.*.config.yaml" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $configFile) {
    Log-Message -Message "No configuration file found matching 'client.*.config.yaml' in the package directory." -Type "ERROR" -LogPath $logPath
    exit
}
$configSource = $configFile.FullName
$configDest = Join-Path -Path $velociraptorDir -ChildPath "client.config.yaml"
try {
    Copy-Item -Path $configSource -Destination $configDest -Force
    Log-Message -Message "Configuration file copied from $configSource to $configDest" -LogPath $logPath
} catch {
    Log-Message -Message "Failed to copy configuration file: $_" -Type "ERROR" -LogPath $logPath
    exit
}

# Post-installation actions: Service restart and DNS check
try {
    Restart-Service "velociraptor" -ErrorAction Stop
    Log-Message -Message "Velociraptor service restarted." -LogPath $logPath
} catch {
    Log-Message -Message "Failed to restart Velociraptor service: $_" -Type "ERROR" -LogPath $logPath
}

# DNS check with logging (does not affect the rest of the script)
$domainToCheck = "velociraptor-minion.az.beazleysecurity.net"
Check-DNS -Domain $domainToCheck -LogPath $logPath

Log-Message -Message "Installation completed successfully." -LogPath $logPath